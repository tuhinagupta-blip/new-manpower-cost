// ═══════════════════════════════════════════════════════════
//  calc.js  —  All manpower cost calculations
//  No dependencies. Pure functions only.
// ═══════════════════════════════════════════════════════════

export const CADRES = ['Management', 'Non Management', 'Contractual', 'Consultant'];

// ── Date helpers ─────────────────────────────────────────────
export function getFYBounds(year) {
  // FY year = the year the FY starts (e.g. 2024 means FY2024-25)
  return {
    start: new Date(year, 3, 1),          // 1 April
    end:   new Date(year + 1, 2, 31),     // 31 March
  };
}

export function getCurrentFY() {
  const now = new Date();
  const y = now.getMonth() >= 3 ? now.getFullYear() : now.getFullYear() - 1;
  return y;
}

export function fyLabel(year) {
  return `FY ${year}–${String(year + 1).slice(2)}`;
}

function clamp(d, lo, hi) {
  if (d < lo) return lo;
  if (d > hi) return hi;
  return d;
}

function daysBetween(a, b) {
  // returns number of days b - a (inclusive of start, exclusive of end)
  // i.e. the number of days the person is "in range"
  const ms = b - a;
  return Math.max(0, Math.round(ms / 86400000));
}

// ── Actual incurred cost (FY start → today) ──────────────────
export function calcActualCost(emp, fyYear) {
  const { start: fyStart } = getFYBounds(fyYear);
  const today = new Date();
  today.setHours(0,0,0,0);

  const activeFrom = new Date(Math.max(fyStart, emp.doj));
  const activeTo   = emp.dol ? new Date(Math.min(today, emp.dol)) : today;

  // clamp to FY
  const s = clamp(activeFrom, fyStart, today);
  const e = clamp(activeTo,   fyStart, today);

  const days = daysBetween(s, e);
  return (emp.ctc / 365) * days;
}

// ── Projected FY cost (FY start → FY end) ────────────────────
export function calcProjectedCost(emp, fyYear) {
  const { start: fyStart, end: fyEnd } = getFYBounds(fyYear);

  const activeFrom = new Date(Math.max(fyStart, emp.doj));
  const activeTo   = emp.dol ? new Date(Math.min(fyEnd, emp.dol)) : fyEnd;

  const s = clamp(activeFrom, fyStart, fyEnd);
  const e = clamp(activeTo,   fyStart, fyEnd);

  const days = daysBetween(s, e);
  return (emp.ctc / 365) * days;
}

// ── Increment-adjusted projected cost ────────────────────────
export function calcIncrementedCost(emp, fyYear, incrementMap) {
  const inc = incrementMap[emp.cadre] || { base: 0, market: 0 };
  const totalPct = (inc.base + inc.market) / 100;
  const adjustedCTC = emp.ctc * (1 + totalPct);
  const empAdjusted = { ...emp, ctc: adjustedCTC };
  return calcProjectedCost(empAdjusted, fyYear);
}

// ── Monthly FY trend ─────────────────────────────────────────
export function calcMonthlyTrend(employees, fyYear, incrementMap = null) {
  const months = [];
  for (let m = 0; m < 12; m++) {
    const monthIdx = (m + 3) % 12;  // April=3, ..., March=2
    const yr = m < 9 ? fyYear : fyYear + 1;
    const mStart = new Date(yr, monthIdx, 1);
    const mEnd   = new Date(yr, monthIdx + 1, 0); // last day of month

    let cost = 0;
    for (const emp of employees) {
      if (emp.invalid || !emp.ctc) continue;
      const ctc = incrementMap
        ? emp.ctc * (1 + ((incrementMap[emp.cadre]?.base || 0) + (incrementMap[emp.cadre]?.market || 0)) / 100)
        : emp.ctc;
      const daily = ctc / 365;

      const activeFrom = new Date(Math.max(mStart, emp.doj));
      const activeTo   = emp.dol ? new Date(Math.min(mEnd, emp.dol)) : mEnd;
      const s = clamp(activeFrom, mStart, mEnd);
      const e = clamp(activeTo,   mStart, mEnd);
      const days = daysBetween(s, e) + 1; // inclusive
      cost += daily * Math.max(0, days);
    }
    months.push({ label: ['Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar'][m], cost });
  }
  return months;
}

// ── Aggregate helpers ─────────────────────────────────────────
export function groupBy(employees, key, fyYear, incrementMap) {
  const map = {};
  for (const emp of employees) {
    if (emp.invalid) continue;
    const k = emp[key] || 'Unknown';
    if (!map[k]) map[k] = { headcount: 0, actual: 0, projected: 0, incremented: 0 };
    map[k].headcount++;
    map[k].actual      += calcActualCost(emp, fyYear);
    map[k].projected   += calcProjectedCost(emp, fyYear);
    map[k].incremented += incrementMap ? calcIncrementedCost(emp, fyYear, incrementMap) : 0;
  }
  return map;
}

// ── Format ────────────────────────────────────────────────────
export function fmtINR(n, decimals = 1) {
  if (n === undefined || n === null || isNaN(n)) return '—';
  const lakhs = n / 100000;
  if (Math.abs(lakhs) >= 100) return `₹${(n / 10000000).toFixed(2)} Cr`;
  return `₹${lakhs.toFixed(decimals)}L`;
}

export function fmtINRFull(n) {
  if (!n && n !== 0) return '—';
  return '₹' + Math.round(n).toLocaleString('en-IN');
}
