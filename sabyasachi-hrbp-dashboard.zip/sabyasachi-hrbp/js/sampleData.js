// ═══════════════════════════════════════════════════════════
//  sampleData.js  —  Generates a sample Excel for demo
// ═══════════════════════════════════════════════════════════

export function generateSampleData() {
  const depts = [
    { dept: 'Finance',             cohort: 'Corporate' },
    { dept: 'Legal',               cohort: 'Corporate' },
    { dept: 'IT',                  cohort: 'Corporate' },
    { dept: 'Womenswear Design',   cohort: 'Design' },
    { dept: 'Accessories Design',  cohort: 'Design' },
    { dept: 'Jewellery Making',    cohort: 'Jewellery Production' },
    { dept: 'Embroidery',          cohort: 'Jewellery Production' },
    { dept: 'HR & Admin',          cohort: 'Corporate' },
  ];
  const cadres = ['Management', 'Non Management', 'Contractual', 'Consultant'];
  const ctcRanges = {
    'Management':      [1200000, 4500000],
    'Non Management':  [360000,  900000],
    'Contractual':     [240000,  600000],
    'Consultant':      [600000,  1800000],
  };

  const rows = [];
  let empNum = 1001;

  function rnd(a, b) { return Math.floor(Math.random() * (b - a + 1)) + a; }
  function rndDate(y, m, d, y2, m2, d2) {
    const d1ms = new Date(y, m - 1, d).getTime();
    const d2ms = new Date(y2, m2 - 1, d2).getTime();
    const ms = d1ms + Math.random() * (d2ms - d1ms);
    const dt = new Date(ms);
    return `${String(dt.getDate()).padStart(2,'0')}/${String(dt.getMonth()+1).padStart(2,'0')}/${dt.getFullYear()}`;
  }

  for (const { dept, cohort } of depts) {
    const count = rnd(4, 10);
    for (let i = 0; i < count; i++) {
      const cadre  = cadres[rnd(0, cadres.length - 1)];
      const [lo, hi] = ctcRanges[cadre];
      const ctc    = Math.round(rnd(lo, hi) / 12000) * 12000;
      const doj    = rndDate(2022, 1, 1, 2025, 10, 1);

      // ~15% chance of being a leaver
      const isLeaver = Math.random() < 0.15;
      const dol = isLeaver ? rndDate(2024, 6, 1, 2025, 11, 30) : '';

      rows.push({
        'Employee ID':   `EMP${empNum++}`,
        'Employee Name': `Employee ${empNum - 1001}`,
        'Department':    dept,
        'Cohort':        cohort,
        'Cadre':         cadre,
        'Annual CTC':    ctc,
        'Date of Joining': doj,
        'Date of Leaving': dol,
      });
    }
  }

  // Build workbook
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, 'Employees');

  // Also append a template sheet
  const tmpl = XLSX.utils.aoa_to_sheet([
    ['Employee ID','Employee Name','Department','Cohort','Cadre','Annual CTC','Date of Joining','Date of Leaving'],
    ['EMP001','Sample Employee','Finance','Corporate','Management','1800000','01/04/2023',''],
    ['EMP002','Sample Employee 2','IT','Corporate','Non Management','600000','15/06/2022','30/09/2024'],
  ]);
  XLSX.utils.book_append_sheet(wb, tmpl, 'Template');

  // Write to ArrayBuffer, return as File object
  const buf = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
  return new File([buf], 'sample_manpower_data.xlsx', {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
}
