// ═══════════════════════════════════════════════════════════
//  export.js  —  Multi-sheet Excel export via SheetJS
// ═══════════════════════════════════════════════════════════
import {
  calcActualCost, calcProjectedCost, calcIncrementedCost,
  groupBy, fmtINRFull, fyLabel, CADRES
} from './calc.js';

function toSheet(data) {
  return XLSX.utils.aoa_to_sheet(data);
}

function currency(n) {
  return Math.round(n || 0);
}

export function exportToExcel(employees, fyYear, incrementMap, filters = {}) {
  const wb = XLSX.utils.book_new();

  // ── 1. Summary sheet ────────────────────────────────────
  const active   = employees.filter(e => !e.invalid && e.active);
  const exited   = employees.filter(e => !e.invalid && !e.active);
  const validAll = employees.filter(e => !e.invalid);

  const totalActual    = validAll.reduce((s, e) => s + calcActualCost(e, fyYear), 0);
  const totalProjected = validAll.reduce((s, e) => s + calcProjectedCost(e, fyYear), 0);
  const totalIncremented = validAll.reduce((s, e) => s + calcIncrementedCost(e, fyYear, incrementMap), 0);

  const summaryData = [
    [`Manpower Budget Dashboard — ${fyLabel(fyYear)}`],
    [],
    ['Metric', 'Value'],
    ['Total Headcount',      employees.length],
    ['Active Headcount',     active.length],
    ['Exited Headcount',     exited.length],
    ['Actual Incurred Cost', currency(totalActual)],
    ['Projected FY Cost',    currency(totalProjected)],
    ['Increment-Adjusted Projected FY Cost', currency(totalIncremented)],
    ['Increment Impact',     currency(totalIncremented - totalProjected)],
    [],
    ['Generated on', new Date().toLocaleString('en-IN')],
  ];
  XLSX.utils.book_append_sheet(wb, toSheet(summaryData), 'Summary');

  // ── 2. Department summary ────────────────────────────────
  const deptGroup = groupBy(validAll, 'dept', fyYear, incrementMap);
  const deptRows  = [
    ['Department', 'Headcount', 'Actual Incurred (₹)', 'Projected FY (₹)', 'Inc-Adjusted Projected (₹)', 'Increment Impact (₹)'],
  ];
  let dTot = { hc:0, act:0, proj:0, inc:0 };
  for (const [k, v] of Object.entries(deptGroup).sort((a,b)=>b[1].headcount-a[1].headcount)) {
    deptRows.push([k, v.headcount, currency(v.actual), currency(v.projected), currency(v.incremented), currency(v.incremented - v.projected)]);
    dTot.hc += v.headcount; dTot.act += v.actual; dTot.proj += v.projected; dTot.inc += v.incremented;
  }
  deptRows.push(['TOTAL', dTot.hc, currency(dTot.act), currency(dTot.proj), currency(dTot.inc), currency(dTot.inc - dTot.proj)]);
  XLSX.utils.book_append_sheet(wb, toSheet(deptRows), 'Department Summary');

  // ── 3. Cohort summary ────────────────────────────────────
  const cohortGroup = groupBy(validAll, 'cohort', fyYear, incrementMap);
  const cohortRows  = [
    ['Cohort', 'Headcount', 'Actual Incurred (₹)', 'Projected FY (₹)', 'Inc-Adjusted Projected (₹)', 'Increment Impact (₹)'],
  ];
  let cTot = { hc:0, act:0, proj:0, inc:0 };
  for (const [k, v] of Object.entries(cohortGroup)) {
    cohortRows.push([k, v.headcount, currency(v.actual), currency(v.projected), currency(v.incremented), currency(v.incremented - v.projected)]);
    cTot.hc += v.headcount; cTot.act += v.actual; cTot.proj += v.projected; cTot.inc += v.incremented;
  }
  cohortRows.push(['TOTAL', cTot.hc, currency(cTot.act), currency(cTot.proj), currency(cTot.inc), currency(cTot.inc - cTot.proj)]);
  XLSX.utils.book_append_sheet(wb, toSheet(cohortRows), 'Cohort Summary');

  // ── 4. Cadre summary ─────────────────────────────────────
  const cadreGroup = groupBy(validAll, 'cadre', fyYear, incrementMap);
  const cadreRows  = [
    ['Cadre', 'Headcount', 'Actual Incurred (₹)', 'Projected FY (₹)', 'Inc-Adjusted Projected (₹)', 'Base Increment %', 'Market Correction %', 'Increment Impact (₹)'],
  ];
  let kTot = { hc:0, act:0, proj:0, inc:0 };
  for (const c of CADRES) {
    const v = cadreGroup[c];
    if (!v) continue;
    const inc = incrementMap[c] || { base:0, market:0 };
    cadreRows.push([c, v.headcount, currency(v.actual), currency(v.projected), currency(v.incremented), inc.base, inc.market, currency(v.incremented - v.projected)]);
    kTot.hc += v.headcount; kTot.act += v.actual; kTot.proj += v.projected; kTot.inc += v.incremented;
  }
  cadreRows.push(['TOTAL', kTot.hc, currency(kTot.act), currency(kTot.proj), currency(kTot.inc), '', '', currency(kTot.inc - kTot.proj)]);
  XLSX.utils.book_append_sheet(wb, toSheet(cadreRows), 'Cadre Summary');

  // ── 5. Increment assumptions ──────────────────────────────
  const incRows = [
    ['Cadre', 'Base Increment %', 'Market Correction %', 'Total %'],
  ];
  for (const c of CADRES) {
    const inc = incrementMap[c] || { base:0, market:0 };
    incRows.push([c, inc.base, inc.market, inc.base + inc.market]);
  }
  XLSX.utils.book_append_sheet(wb, toSheet(incRows), 'Increment Assumptions');

  // ── 6. Employee detail ────────────────────────────────────
  const detailRows = [[
    'Employee ID','Employee Name','Department','Cohort','Cadre',
    'Date of Joining','Date of Leaving','Status',
    'Annual CTC (₹)',
    'Actual Incurred Cost (₹)','Projected FY Cost (₹)',
    'Base Increment %','Market Correction %',
    'Incremented CTC (₹)','Inc-Adjusted Projected FY Cost (₹)',
    'Increment Impact (₹)',
  ]];
  for (const emp of validAll) {
    const inc   = incrementMap[emp.cadre] || { base:0, market:0 };
    const actual = calcActualCost(emp, fyYear);
    const proj   = calcProjectedCost(emp, fyYear);
    const incProj = calcIncrementedCost(emp, fyYear, incrementMap);
    const incCTC  = emp.ctc * (1 + (inc.base + inc.market) / 100);
    detailRows.push([
      emp.id, emp.name,
      emp.dept, emp.cohort, emp.cadre,
      emp.doj ? emp.doj.toLocaleDateString('en-IN') : '',
      emp.dol ? emp.dol.toLocaleDateString('en-IN') : '',
      emp.active ? 'Active' : 'Exited',
      currency(emp.ctc),
      currency(actual), currency(proj),
      inc.base, inc.market,
      currency(incCTC), currency(incProj),
      currency(incProj - proj),
    ]);
  }
  XLSX.utils.book_append_sheet(wb, toSheet(detailRows), 'Employee Detail');

  // ── 7. Assumptions ────────────────────────────────────────
  const assumptionRows = [
    ['Assumption', 'Value', 'Notes'],
    ['Daily Proration Basis', 'Annual CTC ÷ 365', 'Applied uniformly'],
    ['Financial Year', '1 April – 31 March', fyLabel(fyYear)],
    ['Blank Date of Leaving', 'Active till FY end / today', 'Treated as current employee'],
    ['Actual Incurred Cost Period', 'FY Start → Today', 'Only elapsed days'],
    ['Projected FY Cost Period', 'FY Start → FY End', 'Full year eligible days'],
    ['Increment Application', 'CTC × (1 + Base% + Market%)', 'Applied on actual CTC'],
    ['Cadre Values', CADRES.join(', '), 'Strict 4-value set'],
  ];
  XLSX.utils.book_append_sheet(wb, toSheet(assumptionRows), 'Assumptions');

  // ── Write file ────────────────────────────────────────────
  const fname = `manpower_budget_${fyLabel(fyYear).replace(/\s/g,'_')}_${new Date().toISOString().slice(0,10)}.xlsx`;
  XLSX.writeFile(wb, fname);
}
