# Manpower Budget Dashboard — Sabyasachi HRBP

A secure, production-ready manpower budgeting dashboard for HRBP use.  
**No build step. No npm. No backend. Push to GitHub → done.**

---

## Features

- **Upload any Excel file** — flexible column auto-detection with manual mapping fallback
- **Actual incurred cost** — prorated cost from FY start to today
- **Projected FY cost** — full financial year cost (April → March)
- **Increment scenario planning** — editable Base % + Market Correction % per cadre
- **Increment-adjusted projected cost** — live recalculation
- **Monthly FY trend** — current vs increment-adjusted, April to March
- **Filters** — Cohort, Department, Cadre, Active/Exited, Financial Year
- **Sortable detail table** — all employees with full cost calculations
- **Multi-sheet Excel export** — Summary, Dept, Cohort, Cadre, Increment Assumptions, Employee Detail, Assumptions
- **Data validation** — flags invalid rows, duplicate IDs, missing fields
- **Assumptions panel** — always accessible for Finance/HR review meetings
- **100% local** — no data leaves the browser

---

## Cadre Values

The dashboard expects exactly these four cadre/employee type values:

| Cadre |
|-------|
| Management |
| Non Management |
| Contractual |
| Consultant |

Other values will be flagged as warnings but kept in data.

---

## Excel File Format

Your uploaded file should contain these columns (header names are flexible):

| Required Field | Accepted Header Variations |
|---|---|
| Employee ID | Employee ID, Emp ID, EmpID, ID |
| Annual CTC | Annual CTC, CTC, Annual Salary |
| Date of Joining | Date of Joining, DOJ, Joining Date |
| Department | Department, Dept |
| Cadre | Cadre, Employee Type, Grade, Category |

| Optional Field | Accepted Header Variations |
|---|---|
| Employee Name | Employee Name, Name |
| Date of Leaving | Date of Leaving, DOL, Exit Date, LWD |
| Cohort | Cohort, Business Unit, Division |

**Date formats accepted:** DD/MM/YYYY, DD-MM-YYYY, YYYY-MM-DD, Excel serial numbers

---

## Calculation Logic

### Daily Proration
```
Daily Cost = Annual CTC ÷ 365
```

### Actual Incurred Cost (FY Start → Today)
```
Active days = max(FY Start, DOJ) → min(Today, DOL or Today)
Actual Cost = Daily Cost × Active Days
```

### Projected FY Cost (FY Start → FY End)
```
Active days = max(FY Start, DOJ) → min(FY End, DOL or FY End)
Projected Cost = Daily Cost × Active Days
```

### Increment-Adjusted Projected Cost
```
Incremented CTC = Actual CTC × (1 + Base Increment % + Market Correction %)
Inc-Adjusted Cost = (Incremented CTC ÷ 365) × Active Days
```

---

## Local Setup (no install required)

1. Download or clone this repository
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox)
3. Upload your Excel file or click **"load sample data"**

> **Note:** Due to browser security for ES modules, use a simple local server:
> ```
> # Python 3
> python -m http.server 8080
> # then open http://localhost:8080
> ```
> Or use VS Code's Live Server extension.

---

## GitHub Pages Deployment

1. Create a new GitHub repository (public or private)
2. Push all files:
   ```bash
   git init
   git add .
   git commit -m "Initial dashboard"
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
3. Go to **Settings → Pages**
4. Source: **Deploy from branch** → **main** → **/ (root)**
5. Click **Save**
6. Your dashboard will be live at: `https://YOUR_USERNAME.github.io/YOUR_REPO/`

---

## File Structure

```
/
├── index.html          ← Main dashboard (single entry point)
├── css/
│   └── app.css         ← Custom styles
├── js/
│   ├── app.js          ← Main orchestrator
│   ├── calc.js         ← All cost calculations (pure functions)
│   ├── parser.js       ← Excel parsing + column mapping
│   ├── charts.js       ← Chart.js rendering
│   ├── export.js       ← Multi-sheet Excel export
│   └── sampleData.js   ← Sample data generator
└── README.md
```

---

## CDN Dependencies (no download needed)

| Library | Purpose |
|---|---|
| Tailwind CSS (CDN) | Styling |
| Chart.js 4.x | Charts and visualisations |
| SheetJS / xlsx | Excel parsing and export |
| Google Fonts | Playfair Display + DM Sans |

---

## Data Privacy

- All Excel processing happens in your browser
- No employee data is sent to any server
- No cookies, no tracking, no external database
- Safe for use with masked or confidential CTC data

---

## Future Modules (architecture is ready)

The codebase is structured to accommodate future additions:
- Approved manpower budget vs actual
- Open positions tracker
- Proposed hires
- Replacement vs new role classification
- Budget vs actuals variance

---

*Built for Sabyasachi HRBP — Corporate, Design & Jewellery Production*
